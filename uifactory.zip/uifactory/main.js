//import './scripts/initUI.js';

require('./styles/reset.scss');
require('./styles/basic.scss');
require('./styles/layout.scss');
require('./styles/topmenu.scss');
require('./styles/toparea.scss');
require('./styles/gallery.scss');
require('./styles/footer.scss');
require('./styles/photoswipe.scss');
require('./styles/photoswipe-default-skin/default-skin.scss');

require('./styles/projects.scss');
